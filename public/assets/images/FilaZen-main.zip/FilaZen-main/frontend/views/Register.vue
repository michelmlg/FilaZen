<script>
import RegisterForm from '../Components/RegisterForm.vue';
export default {
  name: "Register",
  components: { RegisterForm }
};
</script>
<template>
    <RegisterForm></RegisterForm>
</template>