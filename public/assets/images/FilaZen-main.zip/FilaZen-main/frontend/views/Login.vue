<script>
import LoginForm from '../Components/LoginForm.vue';
export default {
  name: "Register",
  components: { LoginForm }
};

</script>
<template>
    <LoginForm></LoginForm>
</template>