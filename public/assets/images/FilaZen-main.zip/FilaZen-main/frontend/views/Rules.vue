<script>
import Navbar from '../Components/Navbar.vue';
import Navbar from '../Components/Navbar.vue';
export default {
  name: "Rules",
  components: { Navbar }
};
</script>
<template>
  <Navbar></Navbar>
  <h1>Rules</h1>

</template>