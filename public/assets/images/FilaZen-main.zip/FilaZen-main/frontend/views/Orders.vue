<script>
import Navbar from '../Components/Navbar.vue';
export default {
  name: "Orders",
  components: { Navbar }
};
</script>

<template>
  <Navbar></Navbar>
<h1>Orders</h1>

</template>